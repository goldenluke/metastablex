import chess
import random

class QWANEngine:

    def __init__(self):
        pass

    def best_move(self, fen):

        board = chess.Board(fen)

        moves = list(board.legal_moves)

        if len(moves) == 0:
            return None

        # placeholder
        move = random.choice(moves)

        return move.uci()
